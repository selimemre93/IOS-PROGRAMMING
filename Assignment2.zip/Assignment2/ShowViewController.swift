//
//  ShowViewController.swift
//  Assignment2
//
//  Created by Student on 5/23/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class ShowViewController: UIViewController {

    
    var name1:String = ""
    var surname:String = ""
    var id: String = ""
    var gender1: String = ""
    var short : String = ""
    var photo : UIImage?
    
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var lname: UITextField!
    
    
    @IBOutlet weak var ID: UITextField!
    
    
    @IBOutlet weak var gender: UITextField!
    
    @IBOutlet weak var info: UITextField!
  
    @IBOutlet weak var resim: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        gender.text = gender1
        name.text = name1
        lname.text = surname
        info.text = short
        ID.text = id
        
        if(!gender1.isEmpty && !short.isEmpty){
            
        resim.image = photo
        
        }
        
        
        
        
        
        
 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  

}
