//
//  ViewController.swift
//  Assignment2
//
//  Created by Student on 22.05.2017.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var username: String = "selim"
    var password: String = "123456"
    
    
    @IBOutlet weak var userLabel: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func onClick(_ sender: UIButton) {
        
        let myVC = storyboard?.instantiateViewController(withIdentifier:"nextView") as! dataViewController
        
        if(userLabel.text! == username && userPassword.text! == password){
            navigationController?.pushViewController(myVC, animated: true)
        }
        else{
            print("You shall not pass")
        }
    }
    
    
    
    
    
    
}

