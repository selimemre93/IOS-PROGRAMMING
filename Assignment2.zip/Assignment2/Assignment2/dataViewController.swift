//
//  dataViewController.swift
//  Assignment2
//
//  Created by Student on 22.05.2017.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class dataViewController: UIViewController {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var LastnameLabel: UITextField!
    @IBOutlet weak var IdLabel: UITextField!
    @IBOutlet weak var Optional: UISwitch!
    
    @IBOutlet weak var Photo: UIImageView!
    @IBOutlet weak var PhotoLabel: UILabel!
    @IBOutlet weak var Gender: UITextField!
    @IBOutlet weak var GenderLabel: UILabel!
    @IBOutlet weak var Info: UITextField!
    @IBOutlet weak var InfoLabel: UILabel!
    
    @IBOutlet weak var image: UIImageView!
    
    
    
    @IBOutlet weak var submit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
   
    }
   
    @IBAction func Switch(_ sender: UISwitch) {
        
        
        if(sender.isOn == false){
            
            Photo.isHidden = true
            PhotoLabel.isHidden = true
            Gender.isHidden = true
            GenderLabel.isHidden = true
            Info.isHidden = true
            InfoLabel.isHidden = true
            image.isHidden = true
        }
        else{
            Photo.isHidden = false
            PhotoLabel.isHidden = false
            Gender.isHidden = false
            GenderLabel.isHidden = false
            Info.isHidden = false
            InfoLabel.isHidden = false
           
        
        }
        
    }
    
    
    @IBAction func ResetClicked(_ sender: UIButton) {
        
        nameField.text = ""
        LastnameLabel.text = ""
        IdLabel.text = ""
        Gender.text = ""
        Info.text = ""
        
        
    }
    
    
    @IBAction func Term(_ sender: UISwitch) {
        
        if(sender.isOn == false){
            
            submit.isEnabled = false
        
        }
        else{
        
            submit.isEnabled = true
        }
        
        
    }
    
    
    @IBAction func send(_ sender: UIButton) {
        
        let myVC = storyboard?.instantiateViewController(withIdentifier: "info") as! ShowViewController
        
        myVC.name1 = nameField.text!
        myVC.surname = LastnameLabel.text!
        myVC.id = IdLabel.text!
        myVC.gender1 = Gender.text!
        myVC.short = Info.text!
        myVC.photo = image.image 

    
        
        
        navigationController?.pushViewController(myVC, animated: true)
        
        
    }
    
    
    
  
  

}
