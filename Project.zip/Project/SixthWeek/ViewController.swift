//
//  ViewController.swift
//  SixthWeek
//
//  Created by Student on 20/03/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myCarList = []
        let firstCar = UIImageView()
        let SecondCar = UIImageView()
        let ThirdCar = UIImageView()
        let FourthCar = UIImageView()
        firstCar.image = #imageLiteral(resourceName: "Car1")
        SecondCar.image = #imageLiteral(resourceName: "Car2")
        ThirdCar.image = #imageLiteral(resourceName: "Car3")
        FourthCar.image = #imageLiteral(resourceName: "Car4")
        myCarList.append(firstCar)
        myCarList.append(SecondCar)
        myCarList.append(ThirdCar)
        myCarList.append(FourthCar)
        
        PrevButton.isEnabled = false // when we run the program prev button must be disable because when we press the prev button first program show us error.
        firstButton.isEnabled = false
        lastButton.isEnabled = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBOutlet weak var NextButton: UIButton!

    @IBOutlet weak var PrevButton: UIButton!
    
    @IBOutlet weak var Image: UIImageView!
    
    @IBOutlet weak var firstButton: UIButton!
    
    @IBOutlet weak var lastButton: UIButton!
    
    @IBOutlet weak var CopyImage: UIImageView!
    
    @IBOutlet weak var CopyButton: UIButton!
    
    @IBOutlet weak var deleteButton: UIButton!
    
    var i = 0
    
    
    var myCarList:[UIImageView]!
    var CarImage:[UIImage]=[
        UIImage(named:"Car1.jpg")!,
        UIImage(named:"Car2.jpg")!,
        UIImage(named:"Car3.jpg")!,
        UIImage(named:"Car4.jpg")!]
    
    
    @IBAction func PreviousPressed(_ sender: Any) {
        
        i = i - 1
        Image.image = CarImage[i]
        if(i==0){
            NextButton.isEnabled = true
            PrevButton.isEnabled = false
            lastButton.isEnabled = true
            firstButton.isEnabled = false
        }
        else {
            NextButton.isEnabled = true
            PrevButton.isEnabled = true
            lastButton.isEnabled = true
            firstButton.isEnabled = true
        }
        
    }
    
    @IBAction func NextPressed(_ sender: Any) {
        i = i + 1
        
        Image.image = CarImage[i]

        if(CarImage.count - 1 == i ){
            PrevButton.isEnabled = true
            NextButton.isEnabled = false
            firstButton.isEnabled = true
            lastButton.isEnabled = false
        }
        else {
            PrevButton.isEnabled = true
            NextButton.isEnabled = true
            firstButton.isEnabled = true
            lastButton.isEnabled = true
        }
    }
    
  
    @IBAction func firstPressed(_ sender: Any) {
        i = 0
        Image.image = CarImage.first
        PrevButton.isEnabled = false
        NextButton.isEnabled = true
        lastButton.isEnabled = true
        firstButton.isEnabled = false
    }
    
    @IBAction func lastPressed(_ sender: Any) {
        i = CarImage.count - 1
        Image.image = CarImage.last
        PrevButton.isEnabled = true
        NextButton.isEnabled = false
        lastButton.isEnabled = false
        firstButton.isEnabled = true
    }
    
    
    @IBAction func CopyPressed(_ sender: Any) {
        CopyImage.image = Image.image
    }
 
   
    @IBAction func deletePressed(_ sender: Any) {
        CarImage.remove(at: i)
        i = i - 1
    }
    
    
    
}

