//: Playground - noun: a place where people can play

import UIKit


protocol IntBilgi {
    func printIntegerArray(data: [Int]) -> Void
    func sumIntegerArray(data: [Int]) -> Int
}


protocol IntSantral {
    func search(IntegerData: [Int], k: Int) -> Int
    func minNumber(IntegerData: [Int]) -> Int
    func sumTwo(a: Int, b: Int) -> Int
    func sumThree(a: Int, b: Int, c: Int) -> Int
}

protocol  SetGet {
    var name : String {set get}
    var age : Int {set get}
    var id : Int {set get}
    var dept : String {set get}
}

class Person{
    var name: String
    var age: Int
    
    init(){
        name = "Selim Emre Sakarya"
        age = 23
    }
    init(name : String, age : Int){
        self.name = name
        self.age = age
    }
    
    
    public func toString() -> String {
        return ("Name is : \(name), Age is : \(age)")
    }
    
    public func sub(a : Int, b : Int) -> Int {
        
        return a-b
    }
    
}

class Student : Person, IntBilgi, IntSantral{
    var dept : String
    var id : Int
    
    override init(){
        self.dept = "Computer Engineering"
        self.id = 116200102
        super.init()
    }
    
    init(dept: String, id: Int, name: String, age: Int){
        self.dept = dept
        self.id = id
        super.init(name: name, age: age)
    }
    
    public override func toString() -> String {
        return super.toString() + " Department is : \(dept), ID is : \(id)"
    }
    
    public override func sub(a : Int, b : Int) -> Int{
        
        if(a > b){
            return a-b
        }
        else{
            return b-a
        }
    }
    
    func minNumber(IntegerData: [Int]) -> Int {
        var result = IntegerData[0]
        for index in 0..<IntegerData.count  {
            if IntegerData[index] < result{
                result = IntegerData[index]
            }
        }
        return result
    }
    
    func sumTwo(a: Int, b: Int) -> Int {
        return a+b
    }
    
    func sumThree(a: Int, b: Int, c: Int) -> Int {
        return a+b+c
    }
    
    func search(IntegerData: [Int], k: Int) -> Int {
        
        for index in 0..<IntegerData.count  {
            if IntegerData[index]==k {
                return IntegerData[index]
            }
            else{
                return -1
            }
        }
        return k
    }
    
    func sumIntegerArray(data: [Int]) -> Int {
        var sum : Int = 0
        for index in 0..<data.count  {
            sum = sum + data[index]
        }
        return sum
    }
    
    func printIntegerArray(data: [Int]) {
        for index in 0..<data.count  {
            print(data[index], terminator : " ")
        }
    }
    
    
}

// Creating a person with default information and printing it
var p = Person()
print(p.toString())
// Changing p's age and printing it
p.age = 19
print(p.age)
// Creating a student with default information and printing it
var s = Student()
print(s.toString())
// Creating a new student that we can define it and printing it
var s2 = Student(dept: "Industrial Engineering", id: 115200471, name: "Mahmut Ensar Topal", age: 23)
print(s2.toString())
// Creating a new student ..
var s3 = Student(dept: "Mechanical Engineering", id: 112785021, name: "Hüseyin Hakkı Bulut", age: 20)
print(s3.toString())
// Changing s3's name and printing it
s3.name = "Mehmet Yılmaz"
print(s3.name)


var array = [2,3,4,5,6,7]

print(s.minNumber(IntegerData: array))
print(s.search(IntegerData: array, k : 0))
print(s.sumIntegerArray(data: array))
print(s.sumThree(a: 3, b: 2, c: 1))
print(s.sumTwo(a: 1, b: 2))
print(s.printIntegerArray(data: array))




